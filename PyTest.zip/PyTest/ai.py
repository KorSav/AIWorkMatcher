﻿import openai

model = "text-davinci-003"#"text-davinci-003"
openai.api_key = "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"

async def ract_example():
    completions = await openai.Completion.acreate(
        engine=model,
        prompt=
        #"Опишіть вакансію, бажано вказати наступні деталі:"\
        #"• Опис обов'язків\n"\
        #"• Які навички необхідні робітнику\n"\
        #"• Режим роботи\n"\
        #"• Коротка інформація щодо процесу найму\n",
        "Відповідай одним числом, яке є оцінкою."
        "Зараз буде надано 'опис вакансії' та 'моє резюме', запам'ятай інформацію.\n"
        "Опис вакансії: Потрібен дизайнер з досвідом, який буде підтримувати та розвивати бренди, створювати концепції та дизайн для друку, веб-сайтів та соціальних мереж."
        "Необхідні навички:"
        "-Досвід роботи з програмами для дизайну, такими як Adobe Creative Suite."
        "-Знання сучасних дизайн-трендів."
        "-Здатність до розуміння  та реалізації цілей клієнту."
        "-Вміння працювати в тестових умовах і заповнювати запити клієнтів."
        "Режим роботи: на повний робочий день, з 9-00 до 18-00."
        "Процес найму: перегляд резюме, найменування інтерв'ю, проведення тестування, прийом на роботу за умови виконання всіх вимог."
        "Резюме від імені незнайомої людини:"
        " людина має дві-три необхідні навички\n"
        "Кінець резюме."
        "Тепер починай аналіз релевантості резюме до вакансії оцінкою від 0 до 100, де 0 - людина не підходить, 100 - людина підходить"
        #"Якщо текст резюме схожий на критерії оцінок, то відповідай числом 0."
        #"Критерії оцінок:"
        #"Оцінка від 11 до 30: людина має дві-три необхідні навички."
        #"Оцінка від 31 до 50: людина задовольняє третині - половині вимогам."
        #"Оцінка від 51 до 60: людина задовольняє всім вимогам за виключенням однієї - двох."
        #"Оцінка від 61 до 70: людина задовольняє всім вимогам."
        #"Оцінка від 71 до 90: людина задовольняє всім вимогам і вакансія задовольняє деяким її побажанням."
        #"Оцінка від 90 до 100: людина задовольняє всім вимогам і вакансія задовольняє всім її побажанням."
        ,
        max_tokens=5,
        stop=None,
        top_p=0.1,
        #temperature=0.1,
        stream=True,
    )
    async for c in completions:
        yield c["choices"][0]["text"]

async def eact_example():
    completions = await openai.Completion.acreate(
        engine=model,
        prompt=
            "Напиши резюме, вказавши:\n"\
            "- Свої вміння та навички\n"\
            "- На який режим роботи розраховуєш\n"\
            "- Найцікавіші завдання."
        ,
        max_tokens=1000,
        stop=None,
        top_p=0.5,
        #temperature=0.1,
        stream=True,
    )
    async for c in completions:
        yield c["choices"][0]["text"]

async def rate_r(txt_vac: str, txt_res: str):
    completions = await openai.Completion.acreate(
        engine=model,
        prompt=
            "Rate how the CV matches the Vacancy.\n"\
            f"Vacancy:\n{txt_vac}.\n"\
            f"CV:\n{txt_res}\n"\
            "Output only one number which is rate from 0 to 10,"\
            "where 0 - cv doesn`t match a vacancy, 10 - perfect match."\
            "If exists information that is mentioned in Vacancy but not in CV,"\
            "lower rate."\
        ,
        max_tokens=5,
        stop=None,
        top_p=0.3,
        #temperature=0.1,
        stream=False,
    )
    return completions['choices'][0]['text']

async def rate_e(txt_vac: str, txt_res: str):
    completions = await openai.Completion.acreate(
        engine=model,
        prompt=
            "Rate how the CV matches the Vacancy.\n"\
            f"Vacancy:\n{txt_vac}.\n"\
            f"CV:\n{txt_res}\n"\
            "Output only one number which is rate from 0 to 10,"\
            "where 0 - vacancy doesn't match CV, 10 - perfect match."\
            "If exists requirement in Vacancy text but I can't do it according to CV"\
            "lower rate."\
        ,
        max_tokens=5,
        stop=None,
        top_p=0.3,
        #temperature=1,
        stream=False,
    )
    return completions['choices'][0]['text']
