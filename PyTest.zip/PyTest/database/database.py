#encoding: 1251
import sqlite3

con = sqlite3.connect("database\\test.db")
cursor = con.cursor()
COLS = ("type", "telegram_link", "activity_type",
        "activity", "experience", "education", "place")
TRANSLATE = {
        "activity_type": {
            'r': "��� �������� (������ � ������)",
            'e': "��� �������� (������ � ������)"},
        "activity": {
            'r': "���� ������",
            'e': "��������� ���� ������"},
        "experience": {
            'r': "����� ������",
            'e': "����� ������"},
        "education": {
            'r': "г���� �����",
            'e': "г���� �����"},
        "place": {
            'r': "̳��� ������",
            'e': "̳��� ������"},
}
def push(utype, tlink, tact=None, act=None, xp=None, edu=None, place=None):
    fields = {
        "type": utype,
        "telegram_link": "person3",#tlink, #"person3",
        "activity_type": tact,
        "activity": act,
        "experience": xp,
        "education": edu,
        "place": place,
    }
    headers = [i for i,j in fields.items() if j]
    values = [j for j in fields.values() if j]
    if not headers or not values:
        return
    if exist(tlink):
        key_value = []
        args = []
        for i, j in zip(headers, values):
            #data = j.replace("'", "''")
            key_value.append(f"{i}=?")
            args.append(j)
        string = f"UPDATE Users SET {', '.join(key_value)} "\
                 f"WHERE telegram_link='person3'" #'{tlink}'" #'person3'"
        cursor.execute(string, args)
    else:
        string = f"INSERT INTO Users({', '.join(headers)}) "\
                 f"VALUES ({', '.join('?'*len(headers))})"
        cursor.execute(string, values)
    con.commit()

def get_same(kind, tact, xp, edu):
    stype = 'e' if kind == 'r' else 'r' 
    #tact = tact.replace("'", "''")
    #query = "SELECT telegram_link, activity FROM Users WHERE type=? AND activity_type=? AND experience=?"# AND education=?"
    #res = list(cursor.execute(query, (stype, tact, xp)))#, edu)))
    query = "SELECT telegram_link, activity FROM Users WHERE type=? AND activity_type LIKE '%��������%' AND experience=?"# AND education=?"
    res = list(cursor.execute(query, (stype, xp)))#, edu)))
    return res
def get_info(name):
    return list(cursor.execute(f"SELECT * FROM Users WHERE telegram_link='person3'"))[0] #'{name}'"))[0]  #'person3'"))[0]
def get(name, fieldname):
    for i in cursor.execute(f"SELECT {fieldname} FROM Users WHERE telegram_link = 'person3'"): #'{name}'"):  #'person3'"):
        return i[0]
def get_emptycols(name):
    res = []
    for i, data in enumerate(list(cursor.execute(f"SELECT * FROM Users WHERE telegram_link = 'person3'"))[0]): #'{name}'"))[0]):  #'person3'"))[0]):
        print(i, data)
        if data is None:
            res.append(COLS[i])
    return res

def exist(tlink):
    cursor.execute(f"SELECT COUNT(*) FROM Users WHERE telegram_link = 'person3'")#'{tlink}'")  #'person3'")
    if cursor.fetchone()[0] == 0:
        return False
    return True

def remove(tlink):
    cursor.execute(f"DELETE FROM Users WHERE telegram_link = '{tlink}'")


"""
Users - table_name:
type CHAR(1), telegram_link TEXT, activity_type TEXT, 
activity TEXT, experience CHAR(1), education TEXT, place TEXT
"""
