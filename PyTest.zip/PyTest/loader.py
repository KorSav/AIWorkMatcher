from aiogram import Bot, Dispatcher

bot = Bot("5800857900:AAF61XwL5sdZq_3IA1giBt07735iCLNGghc")
dp = Dispatcher(bot)


